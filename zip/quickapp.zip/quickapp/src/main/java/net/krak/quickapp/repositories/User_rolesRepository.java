package net.krak.quickapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.krak.quickapp.entities.User_roles;

public interface User_rolesRepository extends JpaRepository<User_roles, Long> {

}
