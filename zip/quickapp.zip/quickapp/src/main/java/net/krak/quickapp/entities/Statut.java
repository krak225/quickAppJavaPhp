package net.krak.quickapp.entities;

public enum Statut {
    ACTIVE, DESACTIVE, SUPPRIME;
}
