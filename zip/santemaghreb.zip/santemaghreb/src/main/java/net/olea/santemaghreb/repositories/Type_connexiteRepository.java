package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Type_connexite;

public interface Type_connexiteRepository extends JpaRepository<Type_connexite, Long> {

}
