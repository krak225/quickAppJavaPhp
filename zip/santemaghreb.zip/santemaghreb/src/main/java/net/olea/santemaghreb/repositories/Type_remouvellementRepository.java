package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Type_remouvellement;

public interface Type_remouvellementRepository extends JpaRepository<Type_remouvellement, Long> {

}
