package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Type_personne;

public interface Type_personneRepository extends JpaRepository<Type_personne, Long> {

}
