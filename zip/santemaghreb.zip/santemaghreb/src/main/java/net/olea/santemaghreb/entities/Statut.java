package net.olea.santemaghreb.entities;

public enum Statut {
    ACTIVE, DESACTIVE, SUPPRIME;
}
