package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Mouvement_motif;

public interface Mouvement_motifRepository extends JpaRepository<Mouvement_motif, Long> {

}
