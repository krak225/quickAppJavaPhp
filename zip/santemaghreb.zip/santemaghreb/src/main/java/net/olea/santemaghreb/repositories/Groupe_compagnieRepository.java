package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Groupe_compagnie;

public interface Groupe_compagnieRepository extends JpaRepository<Groupe_compagnie, Long> {

}
