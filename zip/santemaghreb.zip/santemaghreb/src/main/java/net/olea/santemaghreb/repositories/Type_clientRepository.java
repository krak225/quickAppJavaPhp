package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Type_client;

public interface Type_clientRepository extends JpaRepository<Type_client, Long> {

}
