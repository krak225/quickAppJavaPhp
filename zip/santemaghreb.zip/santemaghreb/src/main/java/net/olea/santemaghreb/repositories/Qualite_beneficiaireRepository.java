package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Qualite_beneficiaire;

public interface Qualite_beneficiaireRepository extends JpaRepository<Qualite_beneficiaire, Long> {

}
