package net.olea.santemaghreb.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import net.olea.santemaghreb.entities.Type_document;

public interface Type_documentRepository extends JpaRepository<Type_document, Long> {

}
