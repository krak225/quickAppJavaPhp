package net.krak.quickapp.playload.requests;

import lombok.Data;

@Data
public class RoleUserForm {
	public String username;
	public String roleName;
}
